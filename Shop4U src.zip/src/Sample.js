import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: '', price: '' });
  const [editProduct, setEditProduct] = useState({ id: '', name: '', price: '' });
  const [isEditing, setIsEditing] = useState(false);

  // Fetch products from API
  useEffect(() => {
    axios.get('/api/products')
      .then(response => setProducts(response.data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  // Add a new product
  const addProduct = (e) => {
    e.preventDefault();
    axios.post('/api/products', newProduct)
      .then(response => {
        setProducts([...products, response.data]);
        setNewProduct({ name: '', price: '' }); // Clear form
      })
      .catch(error => console.error('Error adding product:', error));
  };

  // Edit an existing product
  const startEditing = (product) => {
    setEditProduct(product);
    setIsEditing(true);
  };

  // Update product
  const updateProduct = (e) => {
    e.preventDefault();
    axios.put(`/api/products/${editProduct.id}`, editProduct)
      .then(response => {
        const updatedProducts = products.map(product => 
          product.id === response.data.id ? response.data : product
        );
        setProducts(updatedProducts);
        setIsEditing(false);
        setEditProduct({ id: '', name: '', price: '' }); // Clear form
      })
      .catch(error => console.error('Error updating product:', error));
  };

  // Delete a product
  const deleteProduct = (id) => {
    axios.delete(`/api/products/${id}`)
      .then(() => {
        const filteredProducts = products.filter(product => product.id !== id);
        setProducts(filteredProducts);
      })
      .catch(error => console.error('Error deleting product:', error));
  };

  return (
    <div>
      <h2>Product Management</h2>

      {/* Add Product Form */}
      <form onSubmit={addProduct}>
        <input
          type="text"
          placeholder="Product Name"
          value={newProduct.name}
          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
        />
        <input
          type="number"
          placeholder="Product Price"
          value={newProduct.price}
          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
        />
        <button type="submit">Add Product</button>
      </form>

      {/* Edit Product Form (if editing) */}
      {isEditing && (
        <form onSubmit={updateProduct}>
          <input
            type="text"
            value={editProduct.name}
            onChange={(e) => setEditProduct({ ...editProduct, name: e.target.value })}
          />
          <input
            type="number"
            value={editProduct.price}
            onChange={(e) => setEditProduct({ ...editProduct, price: e.target.value })}
          />
          <button type="submit">Update Product</button>
        </form>
      )}

      {/* Product List */}
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <span>{product.name} - ${product.price}</span>
            <button onClick={() => startEditing(product)}>Edit</button>
            <button onClick={() => deleteProduct(product.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Products;
