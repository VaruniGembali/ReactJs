import React, { useState } from 'react';
const AddProduct = () => {
 // Initial list of products
 const [products, setProducts] = useState([
   { id: 1, name: 'Product 1', price: 100 },
   { id: 2, name: 'Product 2', price: 200 },
   { id: 3, name: 'Product 3', price: 300 },
 ]);
 // State to manage modal visibility and product input values
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [newProduct, setNewProduct] = useState({ name: '', price: '' });
 // Open the modal
 const openModal = () => {
   setIsModalOpen(true);
 };
 // Close the modal
 const closeModal = () => {
   setIsModalOpen(false);
   setNewProduct({ name: '', price: '' }); // Reset input values
 };
 // Handle input change
 const handleInputChange = (e) => {
   const { name, value } = e.target;
   setNewProduct((prev) => ({
     ...prev,
     [name]: value,
   }));
 };
 // Add the new product to the list
 const handleAddProduct = () => {
   if (!newProduct.name || !newProduct.price) {
     alert('Please fill out all fields');
     return;
   }
   const newProductObject = {
     id: products.length + 1,
     name: newProduct.name,
     price: parseFloat(newProduct.price),
   };
   setProducts([...products, newProductObject]);
   closeModal(); // Close the modal after adding the product
 };
 return (
<div>
<h2>Product List</h2>
<ul>
       {products.map((product) => (
<li key={product.id}>
           {product.name} - ${product.price}
</li>
       ))}
</ul>
     {/* Button to open the modal */}
<button onClick={openModal}>Add New Product</button>
     {/* Modal for adding product */}
     {isModalOpen && (
<div className="modal">
<div className="modal-content">
<h3>Add New Product</h3>
<form onSubmit={(e) => e.preventDefault()}>
<div>
<label>Name:</label>
<input
                 type="text"
                 name="name"
                 value={newProduct.name}
                 onChange={handleInputChange}
                 placeholder="Enter product name"
               />
</div>
<div>
<label>Price:</label>
<input
                 type="number"
                 name="price"
                 value={newProduct.price}
                 onChange={handleInputChange}
                 placeholder="Enter product price"
               />
</div>
<button type="button" onClick={handleAddProduct}>
               Add Product
</button>
<button type="button" onClick={closeModal}>
               Cancel
</button>
</form>
</div>
</div>
     )}
</div>
 );
};
export default AddProduct;