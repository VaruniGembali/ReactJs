import Cart from "./Cart";
import { CartProvider } from "./CartContext";
import Footer from "./Component/Footer";
import Header from "./Component/Header";
import ProductList from "./ProductList";

export default function ConfigureCart(){
console.log("entered to provide list ")

return(
    <div>
        <Header/>
        <CartProvider>
            
            <ProductList/>
            <Cart/>
        </CartProvider>
        <Footer/>
    </div>
)
}
