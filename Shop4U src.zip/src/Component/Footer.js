import React from 'react';
// import './Footer.css'; // Create this file to style the footer

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; 2024 ShopNow. All Rights Reserved.</p>
    </footer>
  );
};

export default Footer;
