import React from 'react';
// import './ProductCard.css'; // Create this file to style your product cards

const ProductCard = ({ product}) => {
  return (
    <div className="product-card" >
      <img src={product.images} alt={product.title}/>
      <h3>{product.id}</h3>
      <h3>{product.title}</h3>
      {/* <p>₹{products.price}</p> */}
      <button>Add to Cart</button>
    </div>
  );
};

export default ProductCard;
